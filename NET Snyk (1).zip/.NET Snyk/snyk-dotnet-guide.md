# Snyk .NET Security Scanning with GitHub Actions

This guide explains how to set up **Snyk** scanning for a .NET project using **GitHub Actions**. It covers prerequisites, setup, and the GitHub Actions workflow that scans dependencies (SCA) and optionally code (SAST).

---

## 1. Prerequisites

- A .NET project with a solution file (`.sln`).
- A GitHub repository where your project is hosted.
- A [Snyk](https://snyk.io) account.
- Your Snyk API Token (`SNYK_TOKEN`).

Generating the Snyk API token in the account settings.

![Alt text for the image](./auth-key.png)

---

## 2. Setup GitHub Repository Secrets

1. Go to your GitHub repository → **Settings** → **Secrets and variables** → **Actions**.
2. Create a new repository secret named `SNYK_TOKEN`.
3. Paste your Snyk API token.

GitHub Secrets page showing the `SNYK_TOKEN` setup.

![Alt text for the image](./github-secret.png)

---

## 3. Add GitHub Actions Workflow

Create a workflow file at `.github/workflows/snyk-dotnet.yml` in your repo with the following content:

```yaml
name: Snyk – .NET Security Scan

on:
  pull_request:
  push:
    branches: [ "main", "release/*" ]
  workflow_dispatch:

jobs:
  security:
    runs-on: ubuntu-latest
    permissions:
      contents: read
      security-events: write
    steps:
      - name: Checkout
        uses: actions/checkout@v4

      - name: Setup .NET
        uses: actions/setup-dotnet@v3
        with:
          dotnet-version: '8.0.x'

      - name: Cache NuGet
        uses: actions/cache@v4
        with:
          path: ~/.nuget/packages
          key: ${{ runner.os }}-nuget-${{ hashFiles('**/*.csproj') }}
          restore-keys: |
            ${{ runner.os }}-nuget-

      - name: Restore solution
        run: dotnet restore ./eShopOnWeb.sln

      - name: Build (Release)
        run: dotnet build ./eShopOnWeb.sln -c Release --no-restore

      # Install Snyk CLI
      - name: Setup Snyk CLI
        uses: snyk/actions/setup@master

      # Dependency (SCA) scan
      - name: Snyk Open Source (SCA) - test
        env:
          SNYK_TOKEN: ${{ secrets.SNYK_TOKEN }}
        run: snyk test --file=./eShopOnWeb.sln --severity-threshold=high
        continue-on-error: true

      # Code (SAST) scan – publishes results to the dashboard
      - name: Snyk Code (SAST)
        env:
          SNYK_TOKEN: ${{ secrets.SNYK_TOKEN }}
        run: snyk code test --severity-threshold=high --report
        continue-on-error: true

      # Upload SCA snapshot only for main/release branches
      - name: Snyk Monitor (SCA snapshot)
        if: github.ref == 'refs/heads/main' || startsWith(github.ref, 'refs/heads/release/')
        env:
          SNYK_TOKEN: ${{ secrets.SNYK_TOKEN }}
        run: snyk monitor --file=./eShopOnWeb.sln
```

GitHub repo file tree with `.github/workflows/snyk-dotnet.yml` added.

![Alt text for the image](./yaml-workflow.png)

---

## 4. Trigger Workflow

- Push to `main` or open a pull request.  
- Go to the **Actions** tab in GitHub to see the pipeline execution.

GitHub Actions run summary with Snyk steps executed.

![Alt text for the image](./summary-workflow.png)

---

## 5. View Results in Snyk Dashboard

After the pipeline runs:

- Go to your [Snyk Dashboard](https://app.snyk.io).
- Under **Projects**, you’ll see your .NET repo listed with:
  - **Open Source (SCA)** findings from your dependencies.
  - (Optional) **Code (SAST)** findings if you extend the workflow with `snyk code test`.

Snyk Projects dashboard view.

![Alt text for the image](./dashboard-view.png)

Example of a project’s vulnerability details.

![Alt text for the image](./vulnerability-details.png)

---

## 6. Optional: Add Snyk Code (SAST)

If you also want code analysis, add these steps after the build:

```yaml
- name: Setup Snyk CLI
  uses: snyk/actions/setup@master

- name: Snyk Code (SAST)
  env:
    SNYK_TOKEN: ${{ secrets.SNYK_TOKEN }}
  run: snyk code test --severity-threshold=high --report
  continue-on-error: true
```

This will show code security issues in your Snyk dashboard.

Snyk Code (SAST) findings view.

![Alt text for the image](./code-analysis.png)

---

## 7. Optional: Other Languages

Snyk supports scanning across stacks. Examples:

| Stack   | CI gate (SCA)                                             | Code (SAST)               | Monitor (UI)                                                 |
| ------- | --------------------------------------------------------- | ------------------------- | ------------------------------------------------------------ |
| .NET    | `snyk test --file=YourSolution.sln`                       | `snyk code test --report` | `snyk monitor --file=YourSolution.sln`                       |
| Node.js | `snyk test --file=package.json`                           | `snyk code test --report` | `snyk monitor --file=package.json`                           |
| Python  | `snyk test --file=requirements.txt --package-manager=pip` | —                         | `snyk monitor --file=requirements.txt --package-manager=pip` |
| Java    | `snyk test --file=pom.xml`                                | `snyk code test --report` | `snyk monitor --file=pom.xml`                                |
| Docker  | `snyk container test <image>`                             | —                         | `snyk container monitor <image>`                             |


## 8. Test vs Monitor

- snyk test: Runs in CI on PRs and pushes. It fails the job if issues above your severity threshold are found (CI gate).

- snyk monitor: Uploads a snapshot of your dependencies to Snyk, where the project is tracked and re-checked automatically when new vulnerabilities are     disclosed.

- Best practice: Run monitor only on main and release/* branches to avoid clutter in the dashboard.

  If scanning multiple projects (```--all-projects```), add ```--exclude=bin,obj,**/tests/**``` to skip test and build output folders.


## 9. Branch Scanning & UI Visibility

Each snapshot in Snyk can be labeled with the branch name using:

```
--target-reference="${{ github.ref_name }}"
```

- This helps you distinguish snapshots for main, release/*, or feature branches.

- Snyk Code (SAST) projects show the most recent commit analysis; SCA projects retain history per snapshot.

## 10. CLI Options & Metadata Conventions

- ```--project-name```: Not supported for .sln files.

- ```--project-tags```: Only works if your org is part of a Snyk Group. Otherwise, you’ll see SNYK-0007.

- If your org joins a Group, use standardized tags like:
```
--project-tags="app=eshoponweb,env=prod,owner=platform"
```

## 11. Scanning Release Branches Without Full CI

Options for scanning release branches without running full pipelines:

- Scheduled job
  Use a ```schedule```: trigger (cron) to run Snyk nightly on ```release/*``` branches.

- Manual run
  Already supported in this workflow with ```workflow_dispatch```. You can trigger scans for any branch manually.

- GitHub App import
  Install the Snyk GitHub App and import your repo. The App runs daily scans automatically, without requiring ```snyk monitor``` in CI.

## 12. Summary

- Snyk Test = CI gate.
- Snyk Monitor = dashboard snapshot, only on main/release.
- Add ```--target-reference``` for branch labeling.
- Use solution-based scanning (```--file=.sln```) for .NET to avoid noisy project files.
- For release branches, choose between scheduled scans, manual runs, or GitHub App import.

