# Snyk .NET Security Scanning with GitHub Actions

This guide explains how to set up **Snyk** scanning for a .NET project using **GitHub Actions**. It covers prerequisites, setup, and the GitHub Actions workflow that scans dependencies (SCA) and optionally code (SAST).

---

## 1. Prerequisites

- A .NET project with a solution file (`.sln`).
- A GitHub repository where your project is hosted.
- A [Snyk](https://snyk.io) account.
- Your Snyk API Token (`SNYK_TOKEN`).

Generating the Snyk API token in the account settings.

![Alt text for the image](./auth-key.png)

---

## 2. Setup GitHub Repository Secrets

1. Go to your GitHub repository → **Settings** → **Secrets and variables** → **Actions**.
2. Create a new repository secret named `SNYK_TOKEN`.
3. Paste your Snyk API token.

GitHub Secrets page showing the `SNYK_TOKEN` setup.

![Alt text for the image](./github-secret.png)

---

## 3. Add GitHub Actions Workflow

Create a workflow file at `.github/workflows/snyk-dotnet.yml` in your repo with the following content:

```yaml
name: Snyk – eShopOnWeb Security Scan

on:
  pull_request:
  push:
    branches: [ "main", "release/*" ]

jobs:
  security:
    runs-on: ubuntu-latest
    permissions:
      contents: read
      security-events: write
    steps:
      - name: Checkout
        uses: actions/checkout@v4

      - name: Setup .NET
        uses: actions/setup-dotnet@v3
        with:
          dotnet-version: '8.0.x'

      - name: Cache NuGet
        uses: actions/cache@v4
        with:
          path: ~/.nuget/packages
          key: ${{ runner.os }}-nuget-${{ hashFiles('**/*.csproj') }}
          restore-keys: |
            ${{ runner.os }}-nuget-

      - name: Restore solution
        run: dotnet restore ./eShopOnWeb.sln

      - name: Build (Release)
        run: dotnet build ./eShopOnWeb.sln -c Release --no-restore

      # Install Snyk CLI (for Snyk Code step)
      - name: Setup Snyk CLI
        uses: snyk/actions/setup@master

      # Dependency (SCA) scan against the solution file
      - name: Snyk Open Source (SCA)
        uses: snyk/actions/dotnet@master
        env:
          SNYK_TOKEN: ${{ secrets.SNYK_TOKEN }}
        with:
          command: test
          args: --file=eShopOnWeb.sln --severity-threshold=high
        continue-on-error: true

      # Code (SAST) scan – keep pipeline going so monitor always runs
      - name: Snyk Code (SAST)
        env:
          SNYK_TOKEN: ${{ secrets.SNYK_TOKEN }}
        run: snyk code test --severity-threshold=high --report
        continue-on-error: true

      # Upload SCA snapshot so results appear in the Snyk dashboard
      - name: Snyk Monitor
        uses: snyk/actions/dotnet@master
        env:
          SNYK_TOKEN: ${{ secrets.SNYK_TOKEN }}
        with:
          command: monitor
          args: --file=eShopOnWeb.sln
```

GitHub repo file tree with `.github/workflows/snyk-dotnet.yml` added.

![Alt text for the image](./yaml-workflow.png)

---

## 4. Trigger Workflow

- Push to `main` or open a pull request.  
- Go to the **Actions** tab in GitHub to see the pipeline execution.

GitHub Actions run summary with Snyk steps executed.

![Alt text for the image](./summary-workflow.png)

---

## 5. View Results in Snyk Dashboard

After the pipeline runs:

- Go to your [Snyk Dashboard](https://app.snyk.io).
- Under **Projects**, you’ll see your .NET repo listed with:
  - **Open Source (SCA)** findings from your dependencies.
  - (Optional) **Code (SAST)** findings if you extend the workflow with `snyk code test`.

Snyk Projects dashboard view.

![Alt text for the image](./dashboard-view.png)

Example of a project’s vulnerability details.

![Alt text for the image](./vulnerability-details.png)

---

## 6. Optional: Add Snyk Code (SAST)

If you also want code analysis, add these steps after the build:

```yaml
- name: Setup Snyk CLI
  uses: snyk/actions/setup@master

- name: Snyk Code (SAST)
  env:
    SNYK_TOKEN: ${{ secrets.SNYK_TOKEN }}
  run: snyk code test --severity-threshold=high --report
  continue-on-error: true
```

This will show code security issues in your Snyk dashboard.

Snyk Code (SAST) findings view.

![Alt text for the image](./code-analysis.png)

---

## 7. Summary

- You’ve configured a GitHub Actions workflow for scanning .NET projects with Snyk.  
- The workflow runs on pull requests and pushes, scanning dependencies (SCA) and optionally code (SAST).  
- Results are viewable both in GitHub Actions logs and in the Snyk dashboard.

